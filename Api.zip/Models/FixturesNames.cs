﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace LabosiOR.Models
{
    public partial class FixturesNames
    {
        public int IdFixture { get; set; }
        public string Season { get; set; }
        public string HomeTeam { get; set; }
        public string AwayTeam { get; set; }
        public int? HomeGoals { get; set; }
        public int? AwayGoals { get; set; }
        public string Referee { get; set; }
        public string Result { get; set; }
        public DateTime Date { get; set; }
        public string Competition { get; set; }
    }
}
