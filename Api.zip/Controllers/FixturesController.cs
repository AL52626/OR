﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Threading.Tasks;
using LabosiOR.DTO;
using LabosiOR.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Fixtures = LabosiOR.DTO.Fixtures;

namespace LabosiOR.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FixturesController : ControllerBase
    {


        private readonly ILogger<FixturesController> _logger;

        private readonly OR_LabContext _ctx;
        public FixturesController(ILogger<FixturesController> logger, OR_LabContext ctx)
        {
            _logger = logger;
            _ctx = ctx;
        }

        [HttpGet]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(Response<List<Fixtures>>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Response<List<Fixtures>>>> GetAll()
        {
            var returnList = new List<Fixtures>();
            try
            {

                var dbList = await _ctx.Fixtures.ToListAsync();

                dbList.ForEach(e =>
                {
                    returnList.Add(new Fixtures
                    {
                        AwayGoals = e.AwayGoals,
                        AwayTeam = _ctx.FootballClubs.Where(e2 => e2.IdFootballClub==e.AwayTeamId).Select(e2 => e2.Name).First(),
                        Competition = e.Competition,
                        Date = e.Date,
                        HomeGoals = e.HomeGoals,
                        HomeTeam = _ctx.FootballClubs.Where(e2 => e2.IdFootballClub==e.HomeTeamId).Select(e2 => e2.Name).First(),
                        IdFixture = e.IdFixture,
                        Referee = e.Referee,
                        Result = e.Result,
                        Season = e.Season
                    });
                });
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }

            return Ok(new Response<List<Fixtures>>(returnList));
        }

        [HttpGet("{id}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(Response<Fixtures>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<Response<Fixtures>> GetFixture(string id)
        {
            Models.Fixtures data;
            try
            {
                data =  _ctx.Fixtures.FirstOrDefault(e => e.IdFixture.ToString()==id);
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }

            return Ok(new Response<Fixtures>(new Fixtures
            {
                AwayGoals = data.AwayGoals,
                AwayTeam = _ctx.FootballClubs.Where(e2 => e2.IdFootballClub == data.AwayTeamId).Select(e2 => e2.Name)
                    .First(),
                Competition = data.Competition,
                Date = data.Date,
                HomeGoals = data.HomeGoals,
                HomeTeam = _ctx.FootballClubs.Where(e2 => e2.IdFootballClub == data.HomeTeamId).Select(e2 => e2.Name)
                    .First(),
                IdFixture = data.IdFixture,
                Referee = data.Referee,
                Result = data.Result,
                Season = data.Season
            }));
        }

        [HttpGet("names")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(Response<List<FixturesNames>>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Response<List<FixturesNames>>>> GetAllFixtureNames()
        {
            var returnList = new List<FixturesNames>();
            try
            {
                returnList = await _ctx.FixturesNames.ToListAsync();
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }

            return Ok(new Response<List<FixturesNames>>(returnList));
        }

        [HttpGet("clubs/{id}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(Response<FootballClubs>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult<Response<FootballClubs>> GetClub(string id)
        {
            FootballClubs fixture;
            try
            {
                fixture =  _ctx.FootballClubs.FirstOrDefault(e => e.IdFootballClub.ToString()==id);
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }

            return Ok(new Response<FootballClubs>(fixture));
        }

        [HttpGet("clubs")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(typeof(Response<List<FootballClubs>>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Response<List<FootballClubs>>>> GetAllClubs()
        {
            var returnList = new List<FootballClubs>();
            try
            {
                 returnList = await _ctx.FootballClubs.ToListAsync();
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }

            return Ok(new Response<List<FootballClubs>>(returnList));
        }

        [HttpPost]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> AddFixture(Fixtures fixture)
        {
            try
            {
                var fix = new Models.Fixtures
                {
                    AwayGoals = fixture.AwayGoals,
                    AwayTeamId = _ctx.FootballClubs.Where(e2 => e2.Name == fixture.AwayTeam)
                        .Select(e2 => e2.IdFootballClub)
                        .First(),
                    Competition = fixture.Competition,
                    Date = fixture.Date,
                    HomeGoals = fixture.HomeGoals,
                    HomeTeamId = _ctx.FootballClubs.Where(e2 => e2.Name == fixture.HomeTeam)
                        .Select(e2 => e2.IdFootballClub)
                        .First(),
                    IdFixture = fixture.IdFixture,
                    Referee = fixture.Referee,
                    Result = fixture.Result,
                    Season = fixture.Season
                };
                var db = await _ctx.Fixtures.AddAsync(fix);
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }

            return NoContent();
        }

        [HttpPut("{id}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult UpdateFixture(Fixtures fixture)
        {
            try
            {
                var fix = new Models.Fixtures
                {
                    AwayGoals = fixture.AwayGoals,
                    AwayTeamId = _ctx.FootballClubs.Where(e2 => e2.Name == fixture.AwayTeam)
                        .Select(e2 => e2.IdFootballClub)
                        .First(),
                    Competition = fixture.Competition,
                    Date = fixture.Date,
                    HomeGoals = fixture.HomeGoals,
                    HomeTeamId = _ctx.FootballClubs.Where(e2 => e2.Name == fixture.HomeTeam)
                        .Select(e2 => e2.IdFootballClub)
                        .First(),
                    IdFixture = fixture.IdFixture,
                    Referee = fixture.Referee,
                    Result = fixture.Result,
                    Season = fixture.Season
                };
                var db = _ctx.Fixtures.Update(fix);
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public ActionResult DeleteFixture(string id)
        {
            try
            {
                var ent = _ctx.Fixtures.FirstOrDefault(e => e.IdFixture.ToString()==id);
                var db = _ctx.Fixtures.Remove(ent);
            }
            catch (Exception e)
            {
                return BadRequest(e);
            }

            return NoContent();
        }
    }
}
