export const domain = "dev-7r0keyl1rehd47tw.us.auth0.com";
export const clientID = "N99OjhEgQsEKFBkNgdSiqyWNxK5nHFsP";

