import {Injectable} from "@angular/core";
import {AuthService} from "@auth0/auth0-angular";
import {Fixtures, Table} from "../mock-api/model";
import {HttpClient} from "@angular/common/http";
import {firstValueFrom} from "rxjs";

@Injectable({
  providedIn: 'root',
})

export class TableService {

  constructor(private httpClient: HttpClient) {
  };

  getFixtures(): Promise<any> {
    const data$ = this.httpClient.get<any>("https://localhost:44372/Fixtures")

    return firstValueFrom(data$);
  }

  exportData(): Promise<void> {
    const data$ = this.httpClient.get<any>("https://localhost:44372/Fixtures/export")

    return firstValueFrom(data$);
  }
}
