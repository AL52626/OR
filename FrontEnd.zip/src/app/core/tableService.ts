import {Injectable} from "@angular/core";
import {AuthService} from "@auth0/auth0-angular";
import {Fixtures, Table} from "../mock-api/model";
import {HttpClient} from "@angular/common/http";
import {firstValueFrom} from "rxjs";

@Injectable({
  providedIn: 'root',
})

export class TableService {

  constructor(private httpClient: HttpClient) {
  };

  async getFixtures(): Promise<any> {
    const data$ = await this.httpClient.get<any>("https://localhost:44372/Fixtures")

    return firstValueFrom(data$);
  }

}
