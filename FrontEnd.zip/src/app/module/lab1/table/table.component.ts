import {Component, OnInit, ViewChild} from '@angular/core';
import {AuthService} from "@auth0/auth0-angular";
import {TableService} from "../../../core/tableService";
import {Comment, Fixtures, Table} from "../../../mock-api/model";
import {MatTableDataSource} from "@angular/material/table";
import {FormArray, FormBuilder, FormControl, FormGroup} from "@angular/forms";
import {MatSort} from "@angular/material/sort";

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
  fixtures: any = [];
  // @ts-ignore
  dataSource: MatTableDataSource<any>;
  columns: string[] = []
  // @ts-ignore
  @ViewChild(MatSort) sort: MatSort;
  // @ts-ignore
  selectedValue: string;
  isAuth = false;

  constructor(private _tableService: TableService, private _formBuilder: FormBuilder, public authService: AuthService) {
  }


  async ngOnInit(): Promise<void> {
    this.authService.isAuthenticated$.subscribe(e => this.isAuth = e.valueOf())
    this.fixtures = (await this._tableService.getFixtures()).data;
    this.columns = Object.keys(this.fixtures[0]);
    this.dataSource = new MatTableDataSource<any>(this.fixtures);
    this.dataSource.sort = this.sort;


  }

  async export() {
    if (this.isAuth)
      await this._tableService.exportData();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    const select = this.selectedValue;
    if (select != null)
      this.dataSource.filterPredicate = function (data, filter: string) {
        let variable = Reflect.get(data, select);
        if (isNaN(Number(variable)))
          return Reflect.get(data, select).toLowerCase().includes(filter);
        else {
          return Reflect.get(data, select) == filter;
        }
      };
    this.dataSource.filter = filterValue.trim().toLowerCase();

    console.log(select)

  }

}
