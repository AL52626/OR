export const environment = {
  production: true,
  auth: {
    redirectUri: globalThis.location.origin
  }
};
