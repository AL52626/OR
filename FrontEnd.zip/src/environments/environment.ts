

export const environment = {
  production: false,
  auth: {
    redirectUri: globalThis.location.origin
  }
};
