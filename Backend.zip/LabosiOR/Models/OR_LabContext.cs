﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace LabosiOR.Models
{
    public partial class OR_LabContext : DbContext
    {
        public OR_LabContext()
        {
        }

        public OR_LabContext(DbContextOptions<OR_LabContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Fixtures> Fixtures { get; set; }
        public virtual DbSet<FixturesNames> FixturesNames { get; set; }
        public virtual DbSet<FootballClubs> FootballClubs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=OR_Lab;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Fixtures>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("fixtures");

                entity.Property(e => e.AwayTeamId).HasColumnName("AwayTeamID");

                entity.Property(e => e.Competition)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Date).HasColumnType("date");

                entity.Property(e => e.HomeTeamId).HasColumnName("HomeTeamID");

                entity.Property(e => e.IdFixture)
                    .HasColumnName("IDFixture")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Referee)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Result)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Season)
                    .IsRequired()
                    .HasMaxLength(9)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<FixturesNames>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("fixtures_names");

                entity.Property(e => e.AwayTeam)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Competition)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Date).HasColumnType("date");

                entity.Property(e => e.HomeTeam)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.IdFixture).HasColumnName("IDFixture");

                entity.Property(e => e.Referee)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Result)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Season)
                    .IsRequired()
                    .HasMaxLength(9)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<FootballClubs>(entity =>
            {
                entity.HasKey(e => e.IdFootballClub);

                entity.ToTable("footballClubs");

                entity.HasIndex(e => new { e.Country, e.Name })
                    .HasName("IX_name_country")
                    .IsUnique();

                entity.Property(e => e.IdFootballClub).HasColumnName("IDFootballClub");

                entity.Property(e => e.Country)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
