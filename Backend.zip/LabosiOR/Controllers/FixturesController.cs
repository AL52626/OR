﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;
using LabosiOR.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.EntityFrameworkCore;
using Fixtures = LabosiOR.DTO.Fixtures;

namespace LabosiOR.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FixturesController : ControllerBase
    {


        private readonly ILogger<FixturesController> _logger;

        private readonly OR_LabContext _ctx;
        public FixturesController(ILogger<FixturesController> logger, OR_LabContext ctx)
        {
            _logger = logger;
            _ctx = ctx;
        }

        [HttpGet]
        public async Task<List<Fixtures>> Get()
        {
            var returnList = new List<Fixtures>();
            var dbList = await _ctx.Fixtures.ToListAsync();

            dbList.ForEach(e =>
            {
                returnList.Add(new Fixtures()
                {
                    AwayGoals = e.AwayGoals,
                    AwayTeam = _ctx.FootballClubs.Where(e2 => e2.IdFootballClub==e.AwayTeamId).Select(e2 => e2.Name).First(),
                    Competition = e.Competition,
                    Date = e.Date,
                    HomeGoals = e.HomeGoals,
                    HomeTeam = _ctx.FootballClubs.Where(e2 => e2.IdFootballClub==e.HomeTeamId).Select(e2 => e2.Name).First(),
                    IdFixture = e.IdFixture,
                    Referee = e.Referee,
                    Result = e.Result,
                    Season = e.Season
                });
            });
            return returnList;
        }
    }
}
